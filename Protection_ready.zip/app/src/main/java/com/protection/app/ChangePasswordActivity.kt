package com.protection.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class ChangePasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        val oldPass = findViewById<EditText>(R.id.oldPass)
        val newPass = findViewById<EditText>(R.id.newPass)
        val changeBtn = findViewById<Button>(R.id.changeBtn)

        changeBtn.setOnClickListener {
            if (oldPass.text.toString() == "1234") {
                Toast.makeText(this, "Password changed!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Old password incorrect", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
