# Protection

An Android app designed to help block and blur explicit content.  
This prototype includes:
- Login screen (username: admin, password: 1234)
- Change password screen
- Background service
- Material Design layout

Automatic APK builds are handled by GitHub Actions.
